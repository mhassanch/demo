import os
import time
import subprocess
import platform
import calendar
from datetime import datetime
from dotenv import load_dotenv

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

from database.insert_data import insert_data, insert_buyer_details, alter_linkedin_buyers, insert_post_details
from database.fetch_data import main, get_posts
from scripts.Ranking import main_process, update_response, format_response

from PyQt5.QtCore import pyqtSignal
from PyQt5.QtWidgets import QWidget
from bs4 import BeautifulSoup
import requests
from tqdm import tqdm
import asyncio


class LinkedInSalesNavigator(QWidget):
    show_message_box = pyqtSignal(str, str)
    def __init__(self, other=None, keyword=None, geography=None, mile=None):
        super().__init__()
        self.keyword = keyword
        self.geography = geography
        self.mile = mile
        self.other = other
        load_dotenv()
    
    def start_driver(self):
        Platform = platform.system()
        if Platform == 'Windows':
            subprocess.call(['taskkill', '/F', '/IM', 'chrome.exe', '/T'])
            user_data_dir = os.path.join(os.getenv('LOCALAPPDATA'), 'Google', 'Chrome', 'User Data')
        elif Platform == 'Darwin':
            # subprocess.call(['pkill', '-9', 'Google Chrome'])
            user_data_dir = os.path.expanduser('~/Library/Application Support/Google/Chrome/')
        elif Platform == 'Linux':
            subprocess.call(['pkill', '-9', 'chrome'])
            user_data_dir = os.path.expanduser('~/.config/google-chrome/')

        os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
        option = webdriver.ChromeOptions()
        option.add_argument("--log-level=3")
        option.add_argument("--silent")
        option.add_argument("--no-sandbox")
        option.add_argument("--disable-dev-shm-usage")
        option.add_argument("--incognito")
        #option.add_argument(f"user-data-dir={user_data_dir}")
        #option.add_argument("profile-directory=Default")
        # option.add_argument('--headless')

        try:
            self.driver = webdriver.Chrome(ChromeDriverManager().install(), options=option)
            self.driver.maximize_window()
            self.wait = WebDriverWait(self.driver, 10)
        except:
            try:
                self.driver = webdriver.Chrome(service=Service(r'chromedriver/chromedriver'), options=option)
                self.driver.maximize_window()
                self.wait = WebDriverWait(self.driver, 10)
            except Exception as e:
                self.other.update_log.emit(f"Error :{e}")
                self.driver.quit()
    
    def scroll(self, count=1):
        try:
            container = self.wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, 'div._search-container_1igybl > div:nth-child(2) > div:nth-child(2)')))
            i = 1
            while True:
                self.driver.execute_script("arguments[0].scrollTop += arguments[0].clientHeight", container)
                if i >= 10:
                    break
                i += 1
                time.sleep(.5)
        except Exception as e:
            if count <= 2:
                self.scroll()
            else:
                self.other.update_log.emit(f"Error: {e}")

    def login(self, link):
        self.driver.get('https://www.linkedin.com/login')
        username = self.wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="username"]')))
        username.send_keys(os.getenv('LINKEDIN_USERNAME'))
        password = self.wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="password"]')))
        password.send_keys(os.getenv('LINKEDIN_PASSWORD'))
        signin = self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#organic-div > form > div.login__form_action_container > button')))
        signin.click()
        if self.driver.current_url in 'https://www.linkedin.com/feed/':
            return
        raise RuntimeError('Need Verification')
    
    def scrape_leads(self):
        soup = BeautifulSoup(self.driver.page_source, 'html.parser')
        elements = soup.find_all(class_='artdeco-entity-lockup__title')

        Leads = []
        for element in elements:
            link = element.find('a')
            if link:
                href = link.get('href')
                Leads.append(f"https://www.linkedin.com{href}")
            else:
                self.other.update_log.emit("No <a> tag found within this element.")
        return Leads

    def scrape_links(self, lead):
        self.driver.get(lead)
        css_selector = "#profile-card-section > section._header_sqh8tm > div._actions-container_1dg5u8._actions-container_sqh8tm._inset-padding_sqh8tm._min-width--medium_sqh8tm._min-width--wide_sqh8tm > section > div > button"
        try:
            button = self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, css_selector)))
            button.click()
            
            element = self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#hue-web-menu-outlet')))
            soup = BeautifulSoup(element.get_attribute('outerHTML'), 'html.parser')
            for a in soup.find_all('a'):
                if 'View LinkedIn profile' in a.get_text(strip=True):
                    profile = a.get('href')
                    return profile
        except:
            self.other.update_log.emit("Profile is Locked and not accessible.")
            return
    
    def scrape(self, login=True):
        LEADS = [[]]
        page = 1
        while True:
            link = f"https://www.linkedin.com/sales/search/people?page={page}&query=(spellCorrectionEnabled%3Atrue%2Cfilters%3AList((type%3APOSTAL_CODE%2Cvalues%3AList((text%3A{self.geography.replace(',', '%252C').replace(' ', '%2520')}%2CselectionType%3AINCLUDED))%2CselectedSubFilter%3A{self.mile}))%2Ckeywords%3A{self.keyword.replace(' ', '%2520')})"

            if login:
                try:
                    self.login(link)
                except RuntimeError:
                    raise RuntimeError('Verify Account!')
            else:
                self.driver.get(link)
                self.scroll()
                
            try:
                Leads = self.scrape_leads()     ## ---->> Get Leads Links
                
                if Leads != LEADS[-1]:
                    LEADS.append(Leads)
                else:
                    break
                
                for lead in tqdm(Leads):
                    profile_link = self.scrape_links(lead)      ## ---->> Get Profile Link
                    if profile_link:
                        try:
                            status = insert_buyer_details([profile_link], check=True)
                        except Exception as e:
                            self.other.update_log.emit(f'Subscription Required!, {e}')
                            return
                        if status == False:
                            buyer_Name, profile_info, experience = self.fetch_profile_info(profile_link)
                            posts_info = self.fetch_posts(profile_link)
                            buyer_details, exp, posts = self.ArrangeData(buyer_Name, profile_info, experience, posts_info, profile_link)
                            try:
                                self.other.update_log.emit("Parsing Data...")
                                ranking_response = asyncio.run(main_process(posts, buyer_details, experience))[-1]
                                self.other.update_log.emit("Ranking Calculated.")
                            except:
                                ranking_response = None
                            if ranking_response:
                                try:
                                    buyer_details.append(lead)
                                    self.other.update_log.emit("Inserting Records into Database...")
                                    insert_data(buyer_details, exp, posts, tuple(ranking_response.values()))
                                    self.other.update_log.emit("Successfully Inserted!")
                                except Exception as e:
                                    self.other.update_log.emit(f'Error: {e}')
                        else:
                            self.other.update_log.emit("Buyer already there in Database.")
                self.other.update_log.emit(f"{'-'*80}")
                self.other.update_log.emit(f"|{' '*30}Page={page} scraped successfully{' '*25}|")
                self.other.update_log.emit(f"{'-'*80}")
                page += 1
            except Exception as e:
                self.other.update_log.emit(f"Internet Connection Timeout Error! {e}")
                return
    
    def recent_search(self):
        try:
            records = asyncio.run(main(['BuyerDetails']))[0]
            for record in tqdm(records):
                buyer_name = record[0]
                previous_info = [record[2], record[3], record[4], record[5], record[6], record[7], record[8]]
                profile_link = record[-2]
                posts = self.fetch_posts(profile_link, posts=50, reposts=50)
                if len(posts) > 0:
                    date, count = asyncio.run(get_posts(buyer_name))
                    if count > 0:
                        post_details = self.process_posts(buyer_name, posts, date=date)
                        if len(post_details) > 0:
                            try:
                                self.other.update_log.emit(f"Parsing Data...")
                                response = format_response(update_response(previous_info, post_details, count))
                                self.other.update_log.emit("Ranking Calculated.")
                                response = list(response[-1].values())
                                response.append(buyer_name)
                                alter_linkedin_buyers(response)
                                insert_post_details(post_details)
                                self.other.update_log.emit("Profile Updated!")
                            except Exception as e:
                                self.other.update_log.emit(f"Error updating buyer details for {buyer_name}: {e}")
                    else:
                        self.other.update_log.emit(f"No new posts found for {buyer_name}.")
                else:
                    self.other.update_log.emit(f"{buyer_name} didn't posted anything.")
        except Exception as e:
            self.other.update_log.emit(f"Error during recent search: {e}")

    def fetch_profile_info(self, link):
        url = "https://linkedin-data-scraper.p.rapidapi.com/person"
        payload = {"link": link}
        headers = {
            "x-rapidapi-key": "fface71b2bmsh13d6596a5d69c1ap1bb049jsnf44a1d15b937",
            "x-rapidapi-host": "linkedin-data-scraper.p.rapidapi.com",
            "Content-Type": "application/json"
        }
        retries = 3
        for attempt in range(retries):
            try:
                response = requests.post(url, json=payload, headers=headers).json()['data']
                try:
                    about = response['about']
                except:
                    about = ''
                data = {
                    "LinkedIn Buyers": response['fullName'],
                    "Headline": response['headline'],
                    "About": about,
                    "Address": response['addressWithoutCountry'],
                    "Country": response['addressCountryOnly']
                }
                self.other.update_log.emit("Profile data Successfully fetched.")
                return response['fullName'], data, [exp for exp in response['experiences']]
            except requests.RequestException as e:
                if attempt < retries - 1:
                    self.other.update_log.emit(f"Error fetching profile info: {e}. Retrying...")
                    time.sleep(2 ** attempt)
                else:
                    self.other.update_log.emit("Failed to fetch profile info after several retries.")
                    return False

    def fetch_posts(self, link, posts=100, reposts=100):
        url = "https://linkedin-data-scraper.p.rapidapi.com/profile_updates"
        payload = {
            "profile_url": link,
            "posts": posts,
            "reposts": reposts
        }
        headers = {
            "x-rapidapi-key": "fface71b2bmsh13d6596a5d69c1ap1bb049jsnf44a1d15b937",
            "x-rapidapi-host": "linkedin-data-scraper.p.rapidapi.com",
            "Content-Type": "application/json"
        }
        try:
            response = requests.post(url, json=payload, headers=headers).json()
            self.other.update_log.emit("Posts/Activities successfully fetched.")
            return [post for post in response['response']]
        except requests.RequestException as e:
            self.other.update_log.emit(f"Error fetching posts: {e}")
            return False
    
    def convert_date(self, date_str):
        try:
            parts = date_str.split()
            if len(parts) != 2:
                self.other.update_log.emit(ValueError("Input should be in the format 'Month Year'"))
                return
            
            month_name, year = parts
            month_number = list(calendar.month_name).index(month_name)
            
            if month_number == 0:
                self.other.update_log.emit(ValueError(f"Month '{month_name}' is not valid."))
                return
            
            formatted_date = f"01-{month_number:02d}-{year}"
            return formatted_date
        
        except Exception as e:
            return None

    def ArrangeData(self, buyer_Name, profile_info, experience, posts_info, profile_link):
        buyer_details = [buyer_Name, profile_info['Headline'], profile_info['About'], profile_info['Address'], profile_info['Country'], self.mile, profile_link]
        Experience = self.process_experience(buyer_Name, experience)
        posts = self.process_posts(buyer_Name, posts_info)
        return buyer_details, Experience, posts
    
    def process_experience(self, buyer_Name, experience):
        Experience = []
        for exp in experience:
            if exp['breakdown'] == True:
                company = exp['title'].split(' · ')[0]
                subcomponent = exp['subComponents']
                
                for sub in subcomponent:
                    position = sub['title']
                    try:desc = sub['description'][0]['text']
                    except:
                        try:desc = sub['description'][0]
                        except:desc = ''
                    try:
                        caption = sub['caption'].split(' - ')
                        start = caption[0]
                        end = caption[1].split(' · ')[0]
                        exper = caption[1].split(' · ')[1]
                    except:
                        start = ''
                        end = ''
                        exper = ''
                    end_ = self.convert_date(end)
                    if end_ is not None:
                        Experience.append((buyer_Name, company, position, desc, self.convert_date(start), 
                            end_, exper, exp.get('metadata', None)))
                    else:
                        Experience.append((buyer_Name, company, position, desc, self.convert_date(start), 
                            'Present', exper, exp.get('metadata', None)))
                    
            else:
                position = exp['title']
                company = exp['subtitle'].split(' · ')[0]
                try:desc = exp['subComponents'][0]['description'][0]['text']
                except:
                    try:desc = exp['subComponents'][0]['description'][0]
                    except:desc = ''
                try:
                    caption = exp['caption'].split(' - ')
                    start = caption[0]
                    end = caption[1].split(' · ')[0]
                    exper = caption[1].split(' · ')[1]
                except:
                    start = ''
                    end = ''
                    exper = ''
                
                Experience.append((buyer_Name, company, position, desc, self.convert_date(start), 
                        self.convert_date(end), exper, exp.get('metadata', None)))
        return Experience

    def process_posts(self, buyer_Name, posts_info, date=None):
        self.posts = []
        for post in posts_info:
            post_datetime = datetime.strptime(post['postedAt'], '%Y-%m-%dT%H:%M:%S.%fZ')
            if date:
                date_datetime = datetime.strptime(date, '%Y-%m-%dT%H:%M:%S.%fZ')
                if post_datetime > date_datetime:
                    self.__validate_post(post, buyer_Name, post['postedAt'])
            else:
                self.__validate_post(post, buyer_Name, post['postedAt'])
        return self.posts
    
    def __validate_post(self, post, buyer_Name, post_datetime):
        url = post['postLink']
        likes = post['socialCount']['numLikes']
        comments = post['socialCount']['numComments']
        
        try:
            description = post['postText']
        except:
            description = ''
        self.posts.append((buyer_Name, url, description, likes, comments, post_datetime))
