import openai
import asyncio
from database.fetch_data import main
from dotenv import load_dotenv
import os


load_dotenv()
openai.api_key = os.getenv('OPENAPI_KEY')

def get_response(posts, headline_about, experience):
    """Generates a response from the OpenAI API based on the provided LinkedIn data."""
    messages = [
        {
            "role": "system",
            "content": (
                "You are an AI model designed to analyze LinkedIn data for real estate investment potential. "
                "Your task is to identify key features from each data section and calculate a ranking based on these features. "
                "Use a strict and consistent pattern across all runs to ensure uniformity in evaluations. "
                "Our main focus is to identify potential buyers who might invest in property. If the profile is not relevant, assign a ranking of 0. "
                "Ensure that the output is in JSON format, even if some fields are empty. "
                "If you encounter irrelevant data, respond with ranking=0. "
                "Do not return placeholder text in the final output; instead, use the actual information provided. "
                "If the profile does not contain the spark to be a potential real estate buyer, then rank it as low as possible. "
                "Classify each profile under one or more of the following property types:"
                " - Retail: Bank, Convenience Store, Day Care Nursery, Fast Food | QSR, Gas Station, Grocery Store, Pharmacy | Drug Store, Restaurant, Bar, StoreFront, Shopping Center, Auto Shop."
                " - MultiFamily: Student Housing, Single Family Rental Portfolio, RV Park, Apartment Buildings."
                " - Office: Traditional Office, Executive Office, Medical Office, Creative Office."
                " - Industrial: Distribution, Flex, Warehouse, R&D, Manufacturing, Refrigerated | Cold Storage."
                " - Hospitality: Hotel, Motel, Casino."
                " - Land: Agricultural, Residential, Commercial, Industrial, Islands, Farm, Ranch, Timber, Hunting Recreational."
                " - Self Storage."
                " - Mobile Home Park."
                " - Senior Living."
                " - Car Wash."
                " - Other: Data Center, Marina, Golf Course, School, Religious Church, Garage Parking, Airport."
                "If a person belongs to more than one type, assign multiple types separated by commas. "
                "Do not assign any type that is not on this list."
            )
        },
        {
            "role": "system",
            "content": (
                "First, analyze the provided LinkedIn post data to identify the types of real estate properties "
                "in which the individual typically invests. Consider descriptions, URLs, number of comments and likes, "
                "and content links. Identify relevant property types, keywords, and any other features that indicate "
                "investment focus, such as 1031 Exchange, Fund, Investing, Cash Flow, and Sponsor. "
                "Based on these identified features, classify the profile into one or more of the predefined types and calculate a ranking percentage as a whole number or as a rounded decimal if the context requires it."
            )
        },
        {"role": "user", "content": f"Here is the provided post data: {posts}"},
        {
            "role": "system",
            "content": (
                "Next, analyze the provided content from the LinkedIn headline and about sections. "
                "Identify keywords or phrases such as 1031 Exchange, 501c, Fund, Investing, Cash Flow, and Sponsor. "
                "Based on the identified key features, classify the profile into one or more of the predefined types and calculate a ranking percentage as a whole number or as a rounded decimal if the context requires it."
            )
        },
        {"role": "user", "content": f"Here's the provided headline and about section: {headline_about}"},
        {
            "role": "system",
            "content": (
                "Finally, analyze the professional experience provided in the data. Evaluate details such as companies "
                "worked for, duration of employment, and niche within real estate. Identify key roles, contributions, "
                "and factors such as syndication, property types, management details, etc. Based on these identified features, "
                "classify the profile into one or more of the predefined types and calculate a ranking percentage as a whole number or as a rounded decimal if the context requires it."
            )
        },
        {"role": "user", "content": f"Here's the provided experience data: {experience}"},
        {
            "role": "system",
            "content": (
                "After calculating the rankings for each section, apply the following weights to determine the overall ranking:"
                " - Headline and About Section: 20%"
                " - Posts: 50%"
                " - Experience: 30%"
                "Return the response in the following JSON format. Replace placeholder text with relevant information from the data:"
                """
                [
                    {
                        'Type': 'List all property types linked to this profile, separated by commas.',
                        'Key Features': 'List the key features identified from posts',
                        'Ranking': 'Calculated whole number or rounded decimal percentage based on posts'
                    },
                    {
                        'Key Features': 'List the key features identified from headline/about section',
                        'Ranking': 'Calculated whole number or rounded decimal percentage based on headline/about section'
                    },
                    {
                        'Key Features': 'List the key features identified from experience section', 
                        'Ranking': 'Calculated whole number or rounded decimal percentage based on experience section'
                    },
                    {
                        'Overall Ranking': 0.2(Headline Ranking) + 0.5(Posts Ranking) + 0.3(Experience Ranking),
                        'Headline Ranking': 'Ranking based on headline and about section',
                        'Posts Ranking': 'Ranking based on posts',
                        'Experience Ranking': 'Ranking based on experience section',
                        'Type': 'List all property types linked to this profile, separated by commas.',
                        'Key Features': 'Merge all the key features of the profile here based on how you ranked the profile. Also, give complete reasoning for your ranking.',
                        'Deficiency': 'List all the irrelevancies in the profile that did not meet the criteria and resulted in a lower ranking.'
                    }
                ]
                """
            )
        }
    ]
    response = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=messages,
        temperature=0.0,
        timeout=60
    )
    return response.choices[0].message.content



def update_response(previous_info, new_posts, n_old):
    """Updates the response by considering previous LinkedIn data analysis and new data, with dynamic ranking adjustments."""
    R1, R2, R3 = previous_info[1], previous_info[2], previous_info[3]
    n_new = len(new_posts)
    messages = [
        {
            "role": "system",
            "content": (
                "You are an AI model designed to update LinkedIn data analysis for real estate investment potential. "
                "You have been provided with previous analysis results including type, ranking, key features, and deficiency. "
                "Your task is to integrate this previous information with new LinkedIn data provided and update the analysis accordingly. "
                "Focus on how the new data might influence the previous conclusions. If the new data contradicts previous findings, "
                "recalculate the relevant sections. Ensure consistency in your evaluations and apply the same strict and uniform pattern. "
                "When calculating the updated ranking, consider the influence of the new data: "
                "If the new post is highly relevant, it should be given more weight in the final ranking calculation. "
                "If no new information significantly changes the previous conclusions, adjust the rankings minimally or leave them unchanged. "
                "Always return the response in JSON format, even if some fields are empty."
                "Make sure to classify each profile under one or more of the following property types:"
                " - Bank, Convenience Store, Day Care Nursery, Fast Food | QSR, Gas Station, Grocery Store, Pharmacy | Drug Store, Restaurant, Bar, StoreFront, Shopping Center, Auto Shop."
                " - Student Housing, Single Family Rental Portfolio, RV Park, Apartment Buildings."
                " - Traditional Office, Executive Office, Medical Office, Creative Office."
                " - Distribution, Flex, Warehouse, R&D, Manufacturing, Refrigerated | Cold Storage."
                " - Hotel, Motel, Casino."
                " - Agricultural, Residential, Commercial, Industrial, Islands, Farm, Ranch, Timber, Hunting Recreational."
                " - Self Storage."
                " - Mobile Home Park."
                " - Senior Living."
                " - Car Wash."
                " - Data Center, Marina, Golf Course, School, Religious Church, Garage Parking, Airport."
                "Do not assign any type that is not on this list. If a person belongs to more than one type, assign multiple types separated by commas."
            )
        },
        {
            "role": "user",
            "content": f"Previous Information: {previous_info}"
        },
        {
            "role": "system",
            "content": (
                "First, re-analyze the provided new LinkedIn post data. "
                "Compare it with previous post-related features and update the property types, key features, and ranking accordingly. "
                "If the new data is highly relevant, it should have a more significant impact on the overall ranking. "
                "Use a weighted approach where the new data can influence up to 60% of the final ranking if it is particularly relevant. "
                "Use the following dynamic ranking formula to adjust the overall ranking: "
                "Let R1 be the ranking for Headline and About Section Relevancy, weighted at 20%. "
                "Let R2 be the ranking for All Activities/Posts, weighted at 50%. "
                "Let R3 be the ranking for Experience Details, weighted at 30%. "
                "Calculate the ratio f as the number of new posts divided by the total number of posts (old and new): "
                f"f = {n_new / (n_old + n_new)}. "
                "Use this ratio to adjust the post ranking weight as follows: "
                f"Adjusted R2 = (1 - f) * {R2} + f * R_new. "
                "Finally, compute the total ranking using: "
                f"Total Ranking = 0.2 * {R1} + 0.5 * Adjusted R2 + 0.3 * {R3}."
            )
        },
        {"role": "user", "content": f"Here is the new post data: {new_posts}"},
        {
            "role": "system",
            "content": (
                "Return the updated response in the following JSON format. Replace placeholder text with updated information:"
                """
                [
                    {
                        'Ranking': 'Total Ranking',
                        'Headline Ranking': R1,
                        'Posts Ranking': Adjusted R2,
                        'Experience Ranking': R3,
                        'Type': 'Updated list of all property types linked to this profile, separated by commas.',
                        'Key Features': 'Updated merged key features of the profile.',
                        'Deficiency': 'Updated irrelevancies in the profile that did not meet the criteria.'
                    }
                ]
                """
            )
        }
    ]
    response = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=messages,
        temperature=0.0
    )
    return response.choices[0].message.content


async def main_process(posts, profile, experience, recent=True):
    """Fetches buyer data and processes it to get responses."""
    try:
        result = get_response(posts, profile, experience)
        formatted_result = format_response(result)
        return formatted_result
    except:
        return None


def format_response(response_text):
    """Formats the API response into the desired list of dictionaries."""
    # Combine lines to ensure the response is a complete Python expression
    try:
        combined_lines = response_text.split('```json\n')[1].split('```')[0]
    except:
        print("Failed to parse", response_text)
        return None
    
    try:
        formatted_response = eval(combined_lines)
    except SyntaxError as e:
        print("SyntaxError while parsing the response: ", e)
        print("Original response text:\n", response_text)
        return None
    return formatted_response


if __name__ == "__main__":
    asyncio.run(main_process())
