from PyQt5.QtCore import QThread, pyqtSignal
from scripts.LinkedInScraper import LinkedInSalesNavigator

class UpdateProfilesThread(QThread):
    update_log = pyqtSignal(str)
    update_done = pyqtSignal()
    
    def __init__(self):
        super().__init__()

    def run(self):
        self.update_log.emit("Updating previous accounts...")
        try:
            LSN = LinkedInSalesNavigator(other=self)
            LSN.recent_search()
            self.update_log.emit("Accounts updated successfully.")
        except Exception as e:
            self.update_log.emit(f"Error during update: {str(e)}")
        finally:
            self.update_done.emit()
