from PyQt5.QtCore import QThread, pyqtSignal, QEventLoop, QTimer
from scripts.LinkedInScraper import LinkedInSalesNavigator
from time import sleep


class ScraperThread(QThread):
    update_log = pyqtSignal(str)
    scraping_done = pyqtSignal(str)
    verification_needed = pyqtSignal()  # Signal to indicate verification is needed

    def __init__(self, keyword, geography, mile, conn):
        super().__init__()
        self.keyword = keyword
        self.geography = geography
        self.mile = mile
        self.conn = conn
        self.is_running = True
        self.verification_acknowledged = False

    def run(self):
        try:
            self.update_log.emit(f"Started scraping for Keyword: {self.keyword}, Geography: {self.geography}, Radius: {self.mile} miles")
            self.LSN = LinkedInSalesNavigator(other=self, keyword=self.keyword, geography=self.geography, mile=self.mile)
            self.LSN.start_driver()

            while self.is_running:
                try:
                    self.LSN.scrape()
                    self.update_log.emit("Scraping completed successfully.")
                    self.scraping_done.emit("success")
                    break
                except RuntimeError as e:
                    if str(e) == "Verify Account!":
                        self.update_log.emit("LinkedIn requires verification. Pausing scraping...")
                        self.verification_needed.emit()
                        self.wait_for_verification_acknowledgement()
                        self.update_log.emit("Verification Successful")
                        sleep(2)
                    try:
                        self.LSN.scrape(login=False)
                    except Exception as e:
                        self.update_log.emit(f"Error after verification: {e}")
                        return
                    else:
                        raise e

        except Exception as e:
            self.scraping_done.emit("error")
        finally:
            if 'conn' in locals():
                self.conn.close()

    def wait_for_verification_acknowledgement(self):
        while not self.verification_acknowledged:
            pass

    def acknowledge_verification(self):
        self.verification_acknowledged = True

    def stop(self):
        self.is_running = False
        self.scraping_done.emit("stopped")
        self.LSN.driver.close()
        
