from PyQt5.QtWidgets import QWidget, QVBoxLayout, QGridLayout, QLabel, QPushButton, QSlider, QGroupBox, QTabWidget, QTableWidget, QTableWidgetItem, QDialog, QVBoxLayout, QTextEdit, QComboBox, QHeaderView, QLineEdit, QMessageBox
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
import asyncio

from ui.custom_combo_box import CustomComboBox
from ui.styles import StyleSheet
from database.ApplyFilter import apply_filter


class SearchDataTab(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        # Add Search Filters Section
        search_group = QGroupBox()
        search_group.setStyleSheet(StyleSheet.group_box)
        filter_layout = QGridLayout()

        # Initialize Type Combo Box with default option
        self.type_combo = CustomComboBox(self, label_text="Select Property Type", button_text="Choose Type", is_location=False)
        filter_layout.addWidget(self.type_combo.label, 0, 0, 1, 2)
        filter_layout.addWidget(self.type_combo.tool_button, 1, 0, 1, 2)

        # Initialize Location Combo Box with default option
        self.location_combo = CustomComboBox(self, label_text="Select Location", button_text="Choose Location", is_location=True)
        filter_layout.addWidget(self.location_combo.label, 0, 2, 1, 2)
        filter_layout.addWidget(self.location_combo.tool_button, 1, 2, 1, 2)

        filter_layout.addWidget(QLabel('Radius in Mile:'), 2, 0)

        # Initialize Radius Slider with an option for "No Selection"
        self.radius_slider_search = QSlider(Qt.Horizontal)
        self.radius_slider_search.setMinimum(0)
        self.radius_slider_search.setMaximum(8)  # 8 positions: 7 for values, 1 for "No Selection"
        self.radius_slider_search.setTickPosition(QSlider.NoTicks)
        self.radius_slider_search.setStyleSheet(StyleSheet.slider)
        self.radius_values_search = [None, 1, 5, 10, 25, 35, 50, 75, 100]  # None represents "No Selection"
        self.radius_slider_search.valueChanged.connect(self.updateRadiusLabelSearch)
        
        # Initialize the radius label with the default value "No Selection"
        self.radius_label_search = QLabel("<span style='font-family: Helvetica; font-size: 14px;'>No Selection</span>")
        self.radius_label_search.setFont(QFont("Helvetica", 12))
        self.radius_label_search.setStyleSheet("font-family: 'Helvetica'; font-size: 12px; color: #5E35B1;")
        filter_layout.addWidget(self.radius_slider_search, 2, 1)
        filter_layout.addWidget(self.radius_label_search, 2, 2)

        # Add Ranking Filter
        filter_layout.addWidget(QLabel('Ranking:'), 3, 0)

        self.ranking_combo = QComboBox(self)
        self.ranking_combo.addItems(['>=', '<=', '=='])
        self.ranking_combo.setStyleSheet(StyleSheet.combo_box)  # Apply the same style as other dropdowns
        filter_layout.addWidget(self.ranking_combo, 3, 1)

        self.ranking_value = QLineEdit(self)
        self.ranking_value.setPlaceholderText("Enter Ranking")
        filter_layout.addWidget(self.ranking_value, 3, 2)

        search_button = QPushButton('Search', self)
        search_button.setFont(QFont("Helvetica", 14, QFont.Bold))
        search_button.setStyleSheet(StyleSheet.search_button)
        search_button.clicked.connect(self.performSearch)
        filter_layout.addWidget(search_button, 4, 0, 1, 4, Qt.AlignCenter)

        search_group.setLayout(filter_layout)
        layout.addWidget(search_group)

        # Create Tab Widget
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        self.setLayout(layout)

    def updateRadiusLabelSearch(self, value):
        if self.radius_values_search[value] is None:
            self.radius_label_search.setText("<span style='font-family: Helvetica; font-size: 14px;'>No Selection</span>")
        else:
            self.radius_label_search.setText(f"<span style='font-family: Helvetica; font-size: 14px;'>{self.radius_values_search[value]}</span> <span style='font-family: Helvetica; font-size: 12px;'>Mile</span>")

    def performSearch(self):
        # Handle the selected types and locations (allow multiple selections)
        selected_types = self.type_combo.get_selected_type().replace('Choose Type', '').split('> ')
        selected_locations = self.location_combo.get_selected_location().replace('Choose Location', '').split('> ')
        selected_radius = self.radius_values_search[self.radius_slider_search.value()]

        # Get Ranking Filter Values
        ranking_condition = self.ranking_combo.currentText()
        ranking_value = self.ranking_value.text()

        # Perform filtering with ranking, types, and locations, and radius if set
        buyer_details, post_details, experience_details = asyncio.run(
            apply_filter(selected_types, selected_locations, selected_radius, ranking_condition, ranking_value)
        )

        # Clear previous tabs
        self.tabs.clear()

        # Check if there are any results; if not, show a message box
        if not buyer_details and not post_details and not experience_details:
            QMessageBox.information(self, "No Results", "No matching records found.", QMessageBox.Ok)
        else:
            # Create Tables for Each Record Set
            self.createTableTab("Buyer Details", buyer_details)
            self.createTableTab("Post Details", post_details)
            self.createTableTab("Experience Details", experience_details)

    def createTableTab(self, tab_name, records):
        if records:
            table = QTableWidget()
            table.setRowCount(len(records))
            table.setColumnCount(len(records[0]))

            if tab_name == "Buyer Details":
                headers = ["Name", "Ranking", "Headline Ranking", "Activities Ranking", "Post Ranking", "Property Types", 
                           "Key Features", "Deficiency", "Headline", "About", "Address", "Country", "Radius", "LinkedIn URL"]
            elif tab_name == "Post Details":
                headers = ["Name", "Link", "Description", "Comments", "Likes", "Posted At"]
            elif tab_name == "Experience Details":
                headers = ["Name", "Company", "Position", "Description", "Start Date", "End Date", "Experience", "Location"]
            else:
                headers = [f"Column {i+1}" for i in range(len(records[0]))]

            table.setHorizontalHeaderLabels(headers)

            # Populate the table
            for i, record in enumerate(records):
                for j, value in enumerate(record):
                    item = QTableWidgetItem(str(value))
                    table.setItem(i, j, item)

            # Enable sorting
            table.setSortingEnabled(True)
            table.horizontalHeader().setSortIndicatorShown(True)
            table.horizontalHeader().sectionClicked.connect(lambda col, t=table, tn=tab_name: self.sortTable(col, t, tn))

            # Connect cell click signal to showCellDialog
            table.cellClicked.connect(self.showCellDialog)

            # Adjust the column width to be concise
            for col in range(table.columnCount()):
                table.setColumnWidth(col, 150)  # Set a fixed width for each column
            table.horizontalHeader().setStretchLastSection(True)  # Stretch the last section to fill the space

            self.tabs.addTab(table, tab_name)

    def sortTable(self, column, table, tab_name):
        # Sort the table based on the selected column
        table.sortItems(column, Qt.AscendingOrder)

        # Update the order in other tabs if sorting Buyer Details
        if tab_name == "Buyer Details":
            buyer_names = [table.item(row, 0).text() for row in range(table.rowCount())]
            self.reorderTabs(buyer_names)

    def reorderTabs(self, sorted_buyer_names):
        # Reorder PostDetails and ExperienceDetails based on the sorted BuyerDetails order
        post_table = self.tabs.widget(1)  # Assuming Post Details is the second tab
        experience_table = self.tabs.widget(2)  # Assuming Experience Details is the third tab

        if post_table:
            self.reorderTable(post_table, sorted_buyer_names)
        if experience_table:
            self.reorderTable(experience_table, sorted_buyer_names)

    def reorderTable(self, table, sorted_buyer_names):
        name_column_index = 1  # Assuming 'Name' is the second column in PostDetails and ExperienceDetails tables
        row_mapping = {}
        
        for row in range(table.rowCount()):
            item = table.item(row, name_column_index)
            if item:  # Check if the item is not None
                row_mapping[item.text()] = row
        
        for i, buyer_name in enumerate(sorted_buyer_names):
            if buyer_name in row_mapping:
                for col in range(table.columnCount()):
                    new_item = table.takeItem(row_mapping[buyer_name], col)
                    table.setItem(i, col, new_item)

    def showCellDialog(self, row, column):
        # Get the table and the cell's content
        table = self.sender()
        cell_value = table.item(row, column).text()

        # Create and display the dialog box
        dialog = QDialog(self)
        dialog.setWindowTitle("Cell Content")
        layout = QVBoxLayout()
        text_edit = QTextEdit()
        text_edit.setText(cell_value)
        text_edit.setReadOnly(True)
        layout.addWidget(text_edit)
        dialog.setLayout(layout)
        dialog.exec_()
