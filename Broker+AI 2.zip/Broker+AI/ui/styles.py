class StyleSheet:
    group_box = """
        background: #ffffff; 
        border-radius: 10px; 
        padding: 15px; 
        border: none;
    """

    line_edit = """
        border: 1px solid #5E35B1;
        border-radius: 10px;
        padding: 8px;
        font-family: 'Helvetica';
        font-size: 14px;
    """

    slider = """
        QSlider::groove:horizontal {
            background: #5E35B1;
            height: 2px;
            border: 1px solid #5E35B1;
            border-radius: 1px;
            margin: 0px 0;
        }
        QSlider::handle:horizontal {
            background: #5E35B1;
            border: 2px solid #FFD700;
            width: 20px;
            height: 20px;
            border-radius: 10px;
            margin: -10px 0;
        }
    """

    scrape_button = """
        QPushButton {
            background-color: #7C4DFF;
            color: white; 
            padding: 12px;
            border-radius: 10px;
            font-family: 'Helvetica';
            font-size: 14px;
        }
        QPushButton:hover {
            background-color: #4A278E;
        }
    """

    stop_button = """
        QPushButton {
            background-color: #FF6666;
            color: white; 
            padding: 12px;
            border-radius: 10px;
            font-family: 'Helvetica';
            font-size: 14px;
        }
        QPushButton:hover {
            background-color: #CC0000;
        }
    """

    text_edit = """
        background-color: #ffffff;
        border: 1px solid #5E35B1;
        border-radius: 10px;
        padding: 8px;
        font-family: 'Helvetica';
        font-size: 14px;
    """

    combo_box = """
        border: 1px solid #5E35B1;
        border-radius: 10px;
        padding: 8px;
        background: #ffffff;
        font-family: 'Helvetica';
        font-size: 14px;
    """

    search_button = """
        QPushButton {
            background-color: #5E35B1;
            color: white; 
            padding: 12px;
            border-radius: 25px;
            font-family: 'Helvetica';
            font-size: 14px;
            border-radius: 10px;
            min-width:400px;
        }
        QPushButton:hover {
            background-color: #4A278E;
        }
    """

    update_button = """
        QPushButton {
            background-color: #5E35B1;
            color: white; 
            padding: 12px;
            border-radius: 25px;
            font-family: 'Helvetica';
            font-size: 14px;
            border-radius: 10px;
            min-width: 200px;
        }
        QPushButton:hover {
            background-color: #4A278E;
        }
    """
    