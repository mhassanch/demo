from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QTextEdit, QLabel, QGroupBox, QMessageBox
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

from threads.udpate_profiles_thread import UpdateProfilesThread
from ui.styles import StyleSheet


class UpdateProfilesTab(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        update_group = QGroupBox()
        update_group.setStyleSheet(StyleSheet.group_box)
        update_layout = QVBoxLayout()

        update_button = QPushButton('Update Accounts', self)
        update_button.setFont(QFont("Helvetica", 14, QFont.Bold))
        update_button.setStyleSheet(StyleSheet.update_button)
        update_button.clicked.connect(self.startUpdatingProfiles)
        update_layout.addWidget(update_button, alignment=Qt.AlignCenter)

        self.log_area = QTextEdit(self)
        self.log_area.setFont(QFont("Helvetica", 12))
        self.log_area.setStyleSheet(StyleSheet.text_edit)
        update_layout.addWidget(QLabel('Logs:'), alignment=Qt.AlignLeft)
        update_layout.addWidget(self.log_area)

        update_group.setLayout(update_layout)
        layout.addWidget(update_group)
        self.setLayout(layout)

    def startUpdatingProfiles(self):
        self.update_profiles_thread = UpdateProfilesThread()
        self.update_profiles_thread.update_log.connect(self.log_area.append)
        self.update_profiles_thread.update_done.connect(self.onUpdateDone)
        self.update_profiles_thread.start()

    def onUpdateDone(self):
        QMessageBox.information(self, 'Update Done', 'Profile update has been completed.')
