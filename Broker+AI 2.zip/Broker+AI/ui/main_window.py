from PyQt5.QtWidgets import QWidget, QVBoxLayout, QTabWidget, QHBoxLayout, QLabel
from PyQt5.QtGui import QPixmap, QFont, QPalette, QColor, QPainter, QBrush
from PyQt5.QtCore import Qt

from database.create_tables import create_tables, create_database
from ui.scraper_tab import ScraperTab
from ui.update_profiles_tab import UpdateProfilesTab
from ui.search_data_tab import SearchDataTab


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        cursor, self.conn = create_database()
        create_tables(cursor)
        self.conn.commit()
        self.initUI()

    def initUI(self):
        self.setFixedSize(600, 800)
        self.setWindowTitle('Broker AI Ranking')

        # Set palette based on the design
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor("#faf3e3"))
        self.setPalette(palette)

        main_layout = QVBoxLayout()

        logo_layout = QHBoxLayout()
        logo = QLabel(self)

        # Load the pixmap
        pixmap = QPixmap("resources/logo.png")
        if pixmap.isNull():
            # Handle the error if the pixmap could not be loaded
            print("Error: Logo image not found or invalid path.")
        else:
            # Create rounded pixmap
            size = min(pixmap.width(), pixmap.height())
            rounded_pixmap = QPixmap(size, size)
            rounded_pixmap.fill(Qt.transparent)

            painter = QPainter(rounded_pixmap)
            painter.setRenderHint(QPainter.Antialiasing)
            painter.setBrush(QBrush(pixmap))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(0, 0, size, size)
            painter.end()

            logo.setPixmap(rounded_pixmap.scaled(100, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation))

        logo_layout.addWidget(logo, alignment=Qt.AlignCenter)

        title = QLabel('Broker AI', self)
        title.setFont(QFont("Helvetica", 22, QFont.Bold))
        title.setStyleSheet("color: #5E35B1; padding-top: 20px; padding-bottom: 10px; margin-right: 150px;")
        title.setAlignment(Qt.AlignCenter)

        logo_layout.addWidget(title, alignment=Qt.AlignCenter)
        main_layout.addLayout(logo_layout)

        # Tabs setup
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabWidget::pane { border: 0; }
            QTabBar::tab { 
                background: #ffffff; 
                color: #5E35B1;
                padding: 10px; 
                margin: 2px; 
                font-size: 14px; 
                font-family: 'Helvetica'; 
                min-width: 120px;
                border-radius: 10px;
            }
            QTabBar::tab:selected { 
                background: #FFD700;
                color: #ffffff;
            }
            QTabBar::tab:hover { 
                background: #FFD700;
                color: #ffffff;
            }
        """)

        # Adding tabs
        self.tabs.addTab(ScraperTab(self.conn), "Scraper")
        self.tabs.addTab(UpdateProfilesTab(), "Update Profiles")
        self.tabs.addTab(SearchDataTab(), "Search Data")

        main_layout.addWidget(self.tabs)
        self.setLayout(main_layout)
        self.show()
