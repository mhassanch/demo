from PyQt5.QtWidgets import QWidget, QVBoxLayout, QGridLayout, QLabel, QLineEdit, QPushButton, QTextEdit, QGroupBox, QMessageBox, QSlider
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from threads.scraper_thread import ScraperThread
from ui.styles import StyleSheet


class ScraperTab(QWidget):
    def __init__(self, conn):
        super().__init__()
        self.conn = conn
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        scrape_group = QGroupBox()
        scrape_group.setStyleSheet(StyleSheet.group_box)

        scrape_layout = QGridLayout()
        scrape_layout.addWidget(QLabel('Keyword:'), 0, 0)
        self.keyword_input = QLineEdit(self)
        self.keyword_input.setFont(QFont("Helvetica", 12))
        self.keyword_input.setStyleSheet(StyleSheet.line_edit)
        scrape_layout.addWidget(self.keyword_input, 0, 1)
        
        scrape_layout.addWidget(QLabel('Geography:'), 1, 0)
        self.geography_input = QLineEdit(self)
        self.geography_input.setFont(QFont("Helvetica", 12))
        self.geography_input.setStyleSheet(StyleSheet.line_edit)
        scrape_layout.addWidget(self.geography_input, 1, 1)
        
        scrape_layout.addWidget(QLabel('Radius in Mile:'), 2, 0)

        # Slider for radius selection
        self.radius_slider = QSlider(Qt.Horizontal)
        self.radius_slider.setMinimum(0)
        self.radius_slider.setMaximum(7)
        self.radius_slider.setTickPosition(QSlider.NoTicks)
        self.radius_slider.setStyleSheet(StyleSheet.slider)
        self.radius_values = [1, 5, 10, 25, 35, 50, 75, 100]
        self.radius_slider.valueChanged.connect(self.updateRadiusLabel)
        
        self.radius_label = QLabel(f"<span style='font-family: Helvetica; font-size: 14px;'>{self.radius_values[0]}</span> <span style='font-family: Helvetica; font-size: 12px;'>Mile</span>")
        self.radius_label.setFont(QFont("Helvetica", 12))
        self.radius_label.setStyleSheet("font-family: 'Helvetica'; font-size: 12px; color: #5E35B1;")
        scrape_layout.addWidget(self.radius_slider, 2, 1)
        scrape_layout.addWidget(self.radius_label, 2, 2)

        scrape_button = QPushButton('Scrape', self)
        scrape_button.setFont(QFont("Helvetica", 14, QFont.Bold))
        scrape_button.setStyleSheet(StyleSheet.scrape_button)
        scrape_button.clicked.connect(self.startScraping)
        scrape_layout.addWidget(scrape_button, 3, 0, 1, 3, Qt.AlignCenter)

        scrape_group.setLayout(scrape_layout)
        layout.addWidget(scrape_group)

        stop_button = QPushButton('  Stop  ', self)
        stop_button.setFont(QFont("Helvetica", 14, QFont.Bold))
        stop_button.setStyleSheet(StyleSheet.stop_button)
        stop_button.clicked.connect(self.stopScraping)
        scrape_layout.addWidget(stop_button, 3, 1, 1, 8, Qt.AlignCenter)

        self.scraper_log_area = QTextEdit(self)
        self.scraper_log_area.setFont(QFont("Helvetica", 12))
        self.scraper_log_area.setStyleSheet(StyleSheet.text_edit)
        layout.addWidget(QLabel('Logs:'), alignment=Qt.AlignLeft)
        layout.addWidget(self.scraper_log_area)

        self.setLayout(layout)

    def updateRadiusLabel(self, value):
        self.radius_label.setText(f"<span style='font-family: Helvetica; font-size: 14px;'>{self.radius_values[value]}</span> <span style='font-family: Helvetica; font-size: 12px;'>Mile</span>")

    def startScraping(self):
        keyword = self.keyword_input.text().strip()
        geography = self.geography_input.text().strip()
        mile = self.radius_values[self.radius_slider.value()]

        if not keyword or not geography or not mile:
            QMessageBox.warning(self, 'Input Error', 'Please enter Keyword, Geography and Radius.')
            return

        self.scraper_thread = ScraperThread(keyword, geography, mile, self.conn)
        self.scraper_thread.update_log.connect(self.scraper_log_area.append)
        self.scraper_thread.scraping_done.connect(self.onScrapingDone)
        self.scraper_thread.verification_needed.connect(self.onVerificationNeeded)
        self.scraper_thread.start()

    def onVerificationNeeded(self):
        QMessageBox.information(self, 'Verification Required', 'LinkedIn requires verification. Please verify on your mobile device and click "Ok" to resume scraping.')
        self.scraper_thread.acknowledge_verification()
        
    def stopScraping(self):
        if hasattr(self, 'scraper_thread') and self.scraper_thread.isRunning():
            self.scraper_thread.stop()
            self.scraper_log_area.append("Scraping forcefully stopped.")

    def onScrapingDone(self, result):
        if result == "success":
            QMessageBox.information(self, 'Scraping Done', 'Scraping has been completed successfully.')
        else:
            QMessageBox.critical(self, 'Scraping Error', 'An error occurred during scraping. Please check the logs.')
