from PyQt5.QtWidgets import QWidget, QVBoxLayout, QToolButton, QMenu, QAction, QLabel, QScrollArea, QVBoxLayout, QWidgetAction, QCheckBox
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

import asyncio
from database.fetch_data import get_address

class CustomComboBox(QWidget):
    def __init__(self, parent=None, label_text="Select Property Type", button_text="Choose Type", is_location=False):
        super().__init__(parent)
        self.label_text = label_text
        self.button_text = button_text
        self.is_location = is_location
        self.selected_items = []  # Store selected items
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)

        self.label = QLabel(self.label_text, self)
        self.label.setFont(QFont("Helvetica", 10, QFont.Bold))
        self.label.setStyleSheet("color: #5E35B1; padding-bottom: 5px;")

        self.tool_button = QToolButton(self)
        self.tool_button.setText(self.button_text)
        self.tool_button.setFont(QFont("Helvetica", 14))
        self.tool_button.setStyleSheet(self.get_button_style())
        self.tool_button.setPopupMode(QToolButton.InstantPopup)

        self.menu = QMenu(self)
        self.menu.setStyleSheet(self.get_menu_style())

        if self.is_location:
            self.populate_location_menu(self.menu)
        else:
            self.populate_menu(self.menu)

        self.tool_button.setMenu(self.menu)

        layout.addWidget(self.label)
        layout.addWidget(self.tool_button)

    def get_button_style(self):
        return """
            QToolButton {
                background-color: #7C4DFF;
                background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 #7C4DFF, stop:1 #4A278E);
                color: white;
                padding: 10px 20px;
                border: 2px solid #4A278E;
                border-radius: 10px;
                font-size: 12px;
                text-align: left;
                min-width: 150px;
                max-width: 150px;
            }
            QToolButton::menu-indicator {
                subcontrol-origin: padding;
                subcontrol-position: center right;
                image: url('resources/dropdown_icon.png');
                padding-left: 10px;
            }
            QToolButton:hover {
                background-color: #4A278E;
                border-color: #3A1E6F;
            }
        """

    def get_menu_style(self):
        return """
            QMenu {
                background-color: #7C4DFF;
                background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 #7C4DFF, stop:1 #4A278E);
                color: white;
                border: 1px solid #4A278E;
                border-radius: 10px;
                padding: 5px;
            }
            QMenu::item {
                padding: 10px;
                border-radius: 5px;
            }
            QMenu::item:selected {
                background-color: #4A278E;
            }
        """

    def populate_menu(self, menu):
        """Populate the menu with types and sub-types"""
        choose_type_action = QAction("Choose Type", self)
        choose_type_action.triggered.connect(self.reset_selection)
        menu.addAction(choose_type_action)

        retail_menu = QMenu("Retail", self)
        retail_menu.setStyleSheet(self.menu.styleSheet())
        retail_subtypes = [
            "Bank", "Convenience Store", "Day Care Nursery", "Fast Food | QSR",
            "Gas Station", "Grocery Store", "Pharmacy | Drug Store",
            "Restaurant", "Bar", "StoreFront", "Shopping Center", "Auto Shop"
        ]
        for subtype in retail_subtypes:
            action = QAction(subtype, self)
            action.setCheckable(True)
            action.triggered.connect(lambda checked, text=subtype: self.update_selected_items(text, checked))
            retail_menu.addAction(action)

        menu.addMenu(retail_menu)

        multifamily_menu = QMenu("MultiFamily", self)
        multifamily_menu.setStyleSheet(self.menu.styleSheet())
        multifamily_subtypes = [
            "Student Housing", "Single Family Rental Portfolio",
            "RV Park", "Apartment Buildings"
        ]
        for subtype in multifamily_subtypes:
            action = QAction(subtype, self)
            action.setCheckable(True)
            action.triggered.connect(lambda checked, text=subtype: self.update_selected_items(text, checked))
            multifamily_menu.addAction(action)

        menu.addMenu(multifamily_menu)

        office_menu = QMenu("Office", self)
        office_menu.setStyleSheet(self.menu.styleSheet())
        office_subtypes = [
            "Traditional Office", "Executive Office",
            "Medical Office", "Creative Office"
        ]
        for subtype in office_subtypes:
            action = QAction(subtype, self)
            action.setCheckable(True)
            action.triggered.connect(lambda checked, text=subtype: self.update_selected_items(text, checked))
            office_menu.addAction(action)

        menu.addMenu(office_menu)

        industrial_menu = QMenu("Industrial", self)
        industrial_menu.setStyleSheet(self.menu.styleSheet())
        industrial_subtypes = [
            "Distribution", "Flex", "Warehouse", "R&D",
            "Manufacturing", "Refrigerated | Cold Storage"
        ]
        for subtype in industrial_subtypes:
            action = QAction(subtype, self)
            action.setCheckable(True)
            action.triggered.connect(lambda checked, text=subtype: self.update_selected_items(text, checked))
            industrial_menu.addAction(action)

        menu.addMenu(industrial_menu)

        hospitality_menu = QMenu("Hospitality", self)
        hospitality_menu.setStyleSheet(self.menu.styleSheet())
        hospitality_subtypes = [
            "Hotel", "Motel", "Casino"
        ]
        for subtype in hospitality_subtypes:
            action = QAction(subtype, self)
            action.setCheckable(True)
            action.triggered.connect(lambda checked, text=subtype: self.update_selected_items(text, checked))
            hospitality_menu.addAction(action)

        menu.addMenu(hospitality_menu)

        land_menu = QMenu("Land", self)
        land_menu.setStyleSheet(self.menu.styleSheet())
        land_subtypes = [
            "Agricultural", "Residential", "Commercial", "Industrial",
            "Islands", "Farm", "Ranch", "Timber", "Hunting Recreational"
        ]
        for subtype in land_subtypes:
            action = QAction(subtype, self)
            action.setCheckable(True)
            action.triggered.connect(lambda checked, text=subtype: self.update_selected_items(text, checked))
            land_menu.addAction(action)

        menu.addMenu(land_menu)
        
        action = QAction("Self Storage", self)
        action.setCheckable(True)
        action.triggered.connect(lambda checked, text="Self Storage": self.update_selected_items(text, checked))
        menu.addAction(action)
        
        action = QAction("Mobile Home Park", self)
        action.setCheckable(True)
        action.triggered.connect(lambda checked, text="Mobile Home Park": self.update_selected_items(text, checked))
        menu.addAction(action)
        
        action = QAction("Senior Living", self)
        action.setCheckable(True)
        action.triggered.connect(lambda checked, text="Senior Living": self.update_selected_items(text, checked))
        menu.addAction(action)
        
        action = QAction("Car Wash", self)
        action.setCheckable(True)
        action.triggered.connect(lambda checked, text="Car Wash": self.update_selected_items(text, checked))
        menu.addAction(action)
        
        other_menu = QMenu("Other", self)
        other_menu.setStyleSheet(self.menu.styleSheet())
        other_subtypes = [
            "Data Center", "Marina", "Golf Course", "School",
            "Religious Church", "Garage Parking", "Airport"
        ]
        for subtype in other_subtypes:
            action = QAction(subtype, self)
            action.setCheckable(True)
            action.triggered.connect(lambda checked, text=subtype: self.update_selected_items(text, checked))
            other_menu.addAction(action)

        menu.addMenu(other_menu)

    def populate_location_menu(self, menu):
        """Populate the location menu with addresses fetched from the database"""
        choose_location_action = QAction('Choose Location', self)
        choose_location_action.triggered.connect(self.reset_selection)
        menu.addAction(choose_location_action)

        # Scrollable area
        scroll_area = QScrollArea()
        scroll_area.setStyleSheet("background-color: transparent;")
        scroll_area.setWidgetResizable(True)

        # Widget to hold all the actions
        scroll_widget = QWidget()
        scroll_layout = QVBoxLayout(scroll_widget)

        address_type_list = asyncio.run(get_address())
        for address in address_type_list:
            checkbox = QCheckBox(address[0], self)
            checkbox.setStyleSheet("color: white; padding: 5px;")
            checkbox.stateChanged.connect(lambda state, text=address[0]: self.update_selected_items(text, state == Qt.Checked))
            scroll_layout.addWidget(checkbox)

        scroll_widget.setLayout(scroll_layout)
        scroll_area.setWidget(scroll_widget)

        # Adding the scrollable area to the menu using QWidgetAction
        scroll_action = QWidgetAction(self)
        scroll_action.setDefaultWidget(scroll_area)
        menu.addAction(scroll_action)

    def update_selected_items(self, text, checked):
        if checked:
            if text not in self.selected_items:
                self.selected_items.append(text)
        else:
            if text in self.selected_items:
                self.selected_items.remove(text)
        self.update_button_text()

    def update_button_text(self):
        if self.selected_items:
            self.tool_button.setText("> ".join(self.selected_items))
        else:
            self.tool_button.setText(self.button_text)

    def reset_selection(self):
        self.selected_items = []
        self.update_button_text()

    def get_selected_type(self):
        return "> ".join(self.selected_items)

    def get_selected_location(self):
        return "> ".join(self.selected_items)
