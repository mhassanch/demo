import aiosqlite

async def apply_filter(types, locations, radius, ranking_condition=None, ranking_value=None):
    async with aiosqlite.connect('Broker+AI.db') as db:
        # Base query for BuyerDetails
        
        query_buyer_details = 'SELECT Name, Ranking, Headline_Relevancy, Activities_Relevancy, Post_Relevancy, Type, KeyFeatures, Deficiency, Headline, About, Address, Country, Radius, LinkedInURL FROM BuyerDetails WHERE 1=1'
        params_buyer_details = []

        # Add Type filter
        if types and types != ['']:
            type_clauses = []
            for t in types:
                type_clauses.append("Type LIKE ?")
                params_buyer_details.append(f'%{t}%')
            query_buyer_details += " AND (" + " OR ".join(type_clauses) + ")"

        # Add Location filter
        if locations and locations != ['']:
            location_clauses = []
            for loc in locations:
                location_clauses.append("Address LIKE ?")
                params_buyer_details.append(f'%{loc}%')
            query_buyer_details += " AND (" + " OR ".join(location_clauses) + ")"

        # Add Radius filter
        if radius is not None:
            query_buyer_details += " AND Radius = ?"
            params_buyer_details.append(radius)

        # Add Ranking filter
        if ranking_condition and ranking_value:
            try:
                ranking_value = float(ranking_value)  # Ensure the ranking value is a number
                query_buyer_details += f" AND Ranking {ranking_condition} ?"
                params_buyer_details.append(ranking_value)
            except ValueError:
                print("Invalid ranking value entered.")

        # Execute BuyerDetails query
        async with db.execute(query_buyer_details, tuple(params_buyer_details)) as cursor:
            buyer_details = await cursor.fetchall()

        # If no buyer details are found, skip fetching post and experience details
        if not buyer_details:
            return [], [], []

        # Extract the names of buyers that matched the filter criteria
        buyer_names = [row[0].strip().lower() for row in buyer_details if isinstance(row[0], str)]  # Assuming the first column is 'Name'

        # Query to fetch PostDetails for matching buyers
        query_post_details = '''
            SELECT pd.Name, pd.Link, pd.Description, pd.Comments, pd.Likes, pd.PostedAt
            FROM PostDetails pd
            WHERE LOWER(TRIM(pd.Name)) IN ({})
        '''.format(','.join('?' * len(buyer_names)))

        # Execute PostDetails query
        async with db.execute(query_post_details, tuple(buyer_names)) as cursor:
            post_details = await cursor.fetchall()

        # Query to fetch ExperienceDetails for matching buyers
        query_experience_details = '''
            SELECT ed.Name, ed.Company, ed.Position, ed.Description, ed.Experience, ed.Location
            FROM ExperienceDetails ed
            WHERE LOWER(TRIM(ed.Name)) IN ({})
        '''.format(','.join('?' * len(buyer_names)))

        # Execute ExperienceDetails query
        async with db.execute(query_experience_details, tuple(buyer_names)) as cursor:
            experience_details = await cursor.fetchall()

        # Organize the results by buyer name
        ordered_post_details = []
        ordered_experience_details = []

        post_dict = {}
        for row in post_details:
            name = row[0].strip().lower()
            if name in post_dict:
                post_dict[name].append(row)
            else:
                post_dict[name] = [row]

        experience_dict = {}
        for row in experience_details:
            name = row[0].strip().lower()
            if name in experience_dict:
                experience_dict[name].append(row)
            else:
                experience_dict[name] = [row]

        for name in buyer_names:
            ordered_post_details.extend(post_dict.get(name, []))
            ordered_experience_details.extend(experience_dict.get(name, []))

    return buyer_details, ordered_post_details, ordered_experience_details
