import aiosqlite
import asyncio

async def delete_data(table_name):
    async with aiosqlite.connect('Broker+AI.db') as db:
        await db.execute(f'DELETE FROM {table_name}')
        await db.commit()
        print(f"Data deleted from {table_name}")

async def fetch_data(table_name):
    async with aiosqlite.connect('Broker+AI.db') as db:
        async with db.execute(f'SELECT * FROM {table_name}') as cursor:
            rows = await cursor.fetchall()
            return rows

async def get_posts(buyer_name):
    async with aiosqlite.connect('Broker+AI.db') as db:
        async with db.execute('''
                                SELECT BuyerDetails.Name, 
                                    MAX(PostDetails.postedAt) AS LastPostDate, 
                                    COUNT(*) AS PostCount
                                FROM BuyerDetails
                                INNER JOIN PostDetails ON BuyerDetails.Name = PostDetails.Name
                                WHERE BuyerDetails.Name = ?
                                GROUP BY BuyerDetails.Name;
                            ''', (buyer_name,)) as cursor:
            row = await cursor.fetchone()
            if row:
                return row[1], row[2]
            else:
                return None

async def get_address():
    async with aiosqlite.connect('Broker+AI.db') as db:
        async with db.execute(f"SELECT DISTINCT Address FROM BuyerDetails ORDER BY SUBSTR(Address, INSTR(Address, ', ') + 2)") as cursor:
            rows = await cursor.fetchall()
            return rows


        
async def main(table_names):
    return await asyncio.gather(
        *[fetch_data(table_name) for table_name in table_names]
    )
    