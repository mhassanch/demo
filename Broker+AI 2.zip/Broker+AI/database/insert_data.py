import sqlite3

        
def insert_buyer_details(records, check=False):
    try:
        with sqlite3.connect('Broker+AI.db') as db:
            cursor = db.cursor()
            if check:
                cursor.execute('''
                    SELECT COUNT(*) FROM BuyerDetails
                    WHERE LinkedInURL = ?
                ''', (records[0],))
                if cursor.fetchone()[0] > 0:
                    return True
                return False
            cursor.execute('''
                INSERT OR IGNORE INTO BuyerDetails (Name, Ranking, Headline_Relevancy, Activities_Relevancy, Post_Relevancy, Type, KeyFeatures, Deficiency, Headline, About, Address, Country, Radius, LinkedInURL, LeadURL)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', records)
            db.commit()
    except Exception as e:
        raise Exception(f"Error inserting Buyer Details: {e}")

def insert_experience_details(records):
    try:
        with sqlite3.connect('Broker+AI.db') as db:
            cursor = db.cursor()
            cursor.executemany('''
                INSERT OR IGNORE INTO ExperienceDetails (Name, Company, Position, Description, StartDate, EndDate, Experience, Location)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', records)
            db.commit()
    except Exception as e:
        raise Exception(f"Error inserting Experience Details: {e}")

def insert_post_details(records):
    try:
        with sqlite3.connect('Broker+AI.db') as db:
            cursor = db.cursor()
            cursor.executemany('''
                INSERT OR IGNORE INTO PostDetails (Name, Link, Description, Comments, Likes, PostedAT)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', records)
            db.commit()
    except Exception as e:
        raise Exception(f"Error inserting Post Details: {e}")

def alter_linkedin_buyers(records):
    try:
        with sqlite3.connect('Broker+AI.db') as db:
            cursor = db.cursor()
            cursor.execute('''
                UPDATE BuyerDetails
                SET Ranking =?, Headline_Relevancy=?, Activities_Relevancy=?, Post_Relevancy=?, Type =?, KeyFeatures =?, Deficiency =?
                WHERE Name =?
            ''', records)
            db.commit()
    except Exception as e:
        raise Exception(f"Error updating Post Details: {e}")

def insert_data(buyer_details, experience, posts, ranking_response):
    try:
        buyer_details[1:1] = ranking_response
        insert_buyer_details(buyer_details)
        insert_experience_details(experience)
        insert_post_details(posts)
    except Exception as e:
        raise Exception(f"An error occurred: {e}")
