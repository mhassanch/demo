import sqlite3

def create_database():
    conn = sqlite3.connect('Broker+AI.db')
    conn.execute('PRAGMA foreign_keys = ON;')
    cursor = conn.cursor()
    return cursor, conn


def create_tables(cursor):
    # -->> Create Buyer Details Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS BuyerDetails (
            Name TEXT PRIMARY KEY,
            Ranking INTEGER,
            Headline_Relevancy INTEGER,
            Activities_Relevancy INTEGER,
            Post_Relevancy INTEGER,
            Type TEXT,
            KeyFeatures TEXT,
            Deficiency TEXT,
            Headline TEXT,
            About TEXT,
            Address TEXT,
            Country TEXT,
            Radius INTEGER,
            LinkedInURL TEXT,
            LeadURL TEXT,
            FOREIGN KEY (Name) REFERENCES LinkedInBuyers(Name) ON DELETE SET NULL
        )
    ''')

    # -->> Create Experience Details Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS ExperienceDetails (
            ExperienceID INTEGER PRIMARY KEY AUTOINCREMENT,
            Name TEXT,
            Company TEXT,
            Position TEXT,
            Description TEXT,
            StartDate DATE,
            EndDate TEXT,
            Experience TEXT,
            Location TEXT,
            FOREIGN KEY (Name) REFERENCES LinkedInBuyers(Name) ON DELETE SET NULL
        )
    ''')

    # -->> Create Post Details Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS PostDetails (
            PostID INTEGER PRIMARY KEY AUTOINCREMENT,
            Name TEXT,
            Link TEXT,
            Description TEXT,
            Comments INTEGER,
            Likes INTEGER,
            PostedAt DATETIME,
            FOREIGN KEY (Name) REFERENCES LinkedInBuyers(Name) ON DELETE SET NULL
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Posts(
            ID INTEGER PRIMARY KEY AUTOINCREMENT,
            Link TEXT,
            Contentlink TEXT,
            Content BLOB,
            Content_type TEXT
        )
    ''')
